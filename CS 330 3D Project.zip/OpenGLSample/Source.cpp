﻿/*
*  CS 330 3D Project
*  CS 330 Computer Graphics & Visualizations
*  Charlotte Mancini
*  Professor Jeff Phillips
*  December 10, 2023
* 
* This program creates and displays a 3D scene.
* It includes keyboard & mouse camera navigation controls.  (keyboard keys include: WASDQE)
* It contains a toggle between orthographic and projection views. (use P key on keyboard) 
*/


// Libraries
#include <GL/glew.h>                                // OpenGl Extension Wrangler Library
#include <GLFW/glfw3.h>                             // Graphics Library Framework

#include <iostream>                                 // Standard I/O
#include <vector>                                   // Standard Vector Library
#include <cmath>                                    // Standard math library

#include "camera.h"                                 // Camera class import

#include <glm/glm.hpp>                              // GLM (OpenGL Mathematics)
#include <glm/gtc/matrix_transform.hpp>             // GLM transformation
#include <glm/gtc/type_ptr.hpp>                     // GLM type pointers

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"                              // Image loading Utility functions

using namespace std;                                // Standard namespace library


// Data Structures
struct Vertex {
    glm::vec3 position;
    glm::vec3 normal;
    glm::vec2 texCoords;  // texture coordinates

    // Constructor
    Vertex(const glm::vec3& pos, const glm::vec3& nor, const glm::vec2& tex)
        : position(pos), normal(nor), texCoords(tex) {}
};

struct Texture {
    GLuint id;

    // Constructor
    Texture(const char* filename) : id(0) {
        // error handling
        if (!loadTexture(filename)) {
            std::cerr << "Failed to load texture!" << filename << std::endl;
        }
    }

    //Destructor
    ~Texture() {
        glDeleteTextures(1, &id);
    }

    // Bind the texture
    void bind(GLenum textureUnit) const {

        glActiveTexture(textureUnit);
        glBindTexture(GL_TEXTURE_2D, id);

    }

    // Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so we must flip it
    void flipImageVertically(unsigned char* image, int width, int height, int channels)
    {
        for (int j = 0; j < height / 2; ++j)
        {
            int index1 = j * width * channels;
            int index2 = (height - 1 - j) * width * channels;

            for (int i = width * channels; i > 0; --i)
            {
                unsigned char tmp = image[index1];
                image[index1] = image[index2];
                image[index2] = tmp;
                ++index1;
                ++index2;
            }
        }
    }

    // Load texture from file
    bool loadTexture(const char* filename) {

        int width, height, channels;

        unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);

        if (image) {

            flipImageVertically(image, width, height, channels);

            glGenTextures(1, &id);
            glBindTexture(GL_TEXTURE_2D, id);

            // Texture parameters
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

            if (channels == 3)
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

            else if (channels == 4)
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

            // Error handling
            else {
                cout << "Not implemented to handle image with " << channels << " channels" << endl;
                stbi_image_free(image);
                return false;
            }

            glGenerateMipmap(GL_TEXTURE_2D);

            stbi_image_free(image);             // Free the image
            glBindTexture(GL_TEXTURE_2D, 0);    // Unbind the texture

            return true;
        }

        // Error loading the image
        return false;
    }
};

struct GLMesh {

private:
    GLuint VAO, VBO, EBO;
    std::vector<Vertex>vertices;
    std::vector<unsigned int> indices;

    void createVertexData() {

        // create buffers/arrays
        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glGenBuffers(1, &EBO);

        // bind VAO
        glBindVertexArray(VAO);

        // load data into vertex buffers
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), vertices.data(), GL_STATIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);

        // set the vertex attribute pointers:

        // vertex Positions
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));

        // vertex normals
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));

        // Texture coordinates
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, texCoords));

        // unbind
        glBindVertexArray(0);
    }

public:

    std::vector<Texture> textures;

    GLMesh(const std::vector<Vertex>& verts, std::vector<unsigned int>& inds)
        : vertices(verts), indices(inds), VAO(0), VBO(0), EBO(0) {
        createVertexData();
    }

    ~GLMesh() {

        glDeleteVertexArrays(1, &VAO);
        glDeleteBuffers(1, &VBO);
        glDeleteBuffers(1, &EBO);
    }

    void bindVAO() const {

        glBindVertexArray(VAO);
    }

    size_t getIndicesCount() const {

        return indices.size();
    }
};

struct TransformData {

    glm::vec3 position;
    glm::vec3 rotation;
    glm::vec3 scale;

    // Translate, rotate, and scale each object
    TransformData(const glm::vec3& pos = glm::vec3(0.0f), const glm::vec3& rot = glm::vec3(0.0f), const glm::vec3& scl = glm::vec3(1.0f))
        :position(pos), rotation(rot), scale(scl) {}

    // Provide transform data to model
    glm::mat4 toMatrix() const {

        glm::mat4 model = glm::mat4(1.0f);

        model = glm::translate(model, position);
        model = glm::rotate(model, glm::radians(rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, scale);

        return model;
    }
};

struct MouseControl {

    glm::vec2 lastMousePos;
    bool firstMouseMovement;
    float sensitivity;

    // constructor & initializations
    MouseControl() : lastMousePos(800.0f / 2.0f, 600.0f / 2), firstMouseMovement(true), sensitivity(0.1f) {}

    // camera speed control function
    static void adjustCameraSpeed(Camera& camera, float offset) {

        float newSpeed = camera.MovementSpeed + offset * 0.25f;
        newSpeed = std::max(0.1f, std::min(newSpeed, 10.0f));         // Set speed limits
        camera.MovementSpeed = newSpeed;
    }

    // function to adjust camera with mouse movement
    void processMouseMovement(GLFWwindow* window, Camera& camera, float deltaTime) {

        double mouseX, mouseY;

        glfwGetCursorPos(window, &mouseX, &mouseY);

        if (firstMouseMovement) {
            lastMousePos.x = mouseX;
            lastMousePos.y = mouseY;
            firstMouseMovement = false;
        }

        float xOffset = (mouseX - lastMousePos.x) * sensitivity;
        float yOffset = (lastMousePos.y - mouseY) * sensitivity;

        lastMousePos.x = mouseX;
        lastMousePos.y = mouseY;

        camera.ProcessMouseMovement(xOffset, yOffset);
    }

    // function to adjust camera speed
    static void scrollCallback(GLFWwindow* window, double xoffset, double yoffset) {

        Camera* camera = static_cast<Camera*>(glfwGetWindowUserPointer(window));

        if (camera) {
            MouseControl::adjustCameraSpeed(*camera, static_cast<float>(yoffset));
        }
    }

};

struct AppContext {

    // struct to hold pointers for camera & mouse positions
    Camera* camera;
    MouseControl* mouseControl;
};

struct Light {
    glm::vec3 position;
    glm::vec3 direction;
    glm::vec3 ambient;
    glm::vec3 diffuse;
    glm::vec3 specular;
    float intensity;
};


// Function Prototypes 

GLFWwindow* createWindow(int width, int height, const char* title);
GLuint compileShader(GLenum type, const GLchar* source);

bool isOpenGLError();
void initGLFW();
void initApp(GLFWwindow*& window, GLuint& shaderProgram, Camera& camera, MouseControl& mouseControl);
void checkLinking(GLuint program);
void createShaderProgram(GLuint& shaderProgram);
void setLightProperties(const GLuint shaderProgram, const Light& light, const std::string& name);
void checkShaderCompilation(GLuint shader);

void createCylinder(std::vector<Vertex>& cylinderVertices, std::vector<unsigned int>& cylinderIndices,
    float radius, float height, int numSlices);
void createHalfTorus(std::vector<Vertex>& vertices, std::vector<unsigned int>& indices,
    float outerRadius, float innerRadius, int numSlices, int numStacks, const glm::vec3& color);
void createTaperedCylinder(std::vector<Vertex>& cylinderVertices, std::vector<unsigned int>& cylinderIndices,
    float bottomRadius, float topRadius, float height, int numSlices);
void createPencil(std::vector<Vertex>& pencilVertices, std::vector<int>& pencilIndices);
void createRuler(std::vector<Vertex>& rulerVertices, std::vector<Vertex>& rulerIndices);

void applyProjectionAndMatrix(GLuint shaderProgram, const glm::mat4& modelMatrix, const glm::mat4& viewMatrix, bool isPerspectiveView);
void renderShape(const GLMesh& mesh);
void renderScene(GLFWwindow* window, GLMesh& mesh, GLuint& shaderProgram, Camera& camera, bool isPerspectiveView, Texture& texture1, Texture& texture2, float blendFactor, TransformData& transformData);

void processInput(GLFWwindow* window, Camera& camera, float deltaTime, bool& isPerspectiveView);
void mouseCallback(GLFWwindow* window, double xpos, double ypos);
void adjustCameraSpeed(Camera& camera, float offset);


// Shader sources
const char* vertexShaderSource = R"(

    #version 330 core

    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 aNormal;
    layout (location = 2) in vec2 aTexCoords; // Texture coordinates input
    
    out vec2 TexCoords; // Pass to fragment shader
    out vec3 normal;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(aPos, 1.0);
        normal = aNormal;
        TexCoords = aTexCoords;
    }
)";


const char* fragmentShaderSource = R"(

     #version 330 core

     in vec2 TexCoords;
     in vec3 FragNormal;
     in vec3 FragPos;

     out vec4 FragColor;

     uniform sampler2D texture1;
     uniform sampler2D texture2;
     uniform float blendFactor;

     // Define the key light properties
     struct KeyLight {
        vec3 position; 
        vec3 direction;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        float intensity;
     };

     uniform KeyLight keyLight;

     // Define the fill light properties
     struct FillLight {
        vec3 position;
        vec3 direction;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        float intensity;
     };

     uniform FillLight fillLight;

     void main() {

        vec3 textureColor1 = texture(texture1, TexCoords).rgb * 1.2;
        vec3 textureColor2 = texture(texture2, TexCoords).rgb * 1.2;

        // Key Light Calculations:

        vec3 normKey = normalize(FragNormal);
        vec3 lightDirKey = normalize(keyLight.position - FragPos);

        vec3 ambientKey = (keyLight.ambient * vec3(0.5) + textureColor1);

        vec3 diffuseKey = (keyLight.diffuse * textureColor1);

        vec3 reflectDirKey = reflect(-lightDirKey, normKey);
        float specKey = pow(max(dot(-FragPos, reflectDirKey), 0.0), 32.0);
        vec3 specularKey = (keyLight.specular * (specKey * textureColor1));

        vec3 keyLightColor = ambientKey + diffuseKey + specularKey;

      
        // Fill Light Calculations:

        vec3 normFill = normalize(FragNormal);
        vec3 lightDirFill = normalize(fillLight.position - FragPos);
        vec3 blueTint = vec3(0.0, 0.0, 0.05); // barely blue
        vec3 yellowTint = vec3(0.0, 1.0, 0.0); // yellow tint
        
        // Adjust fill light color to blue hue to satisfy rubric criteria
        vec3 ambientFill = (fillLight.ambient * vec3(0.5) + 0.5 * textureColor2) * blueTint;

        float diffFill = max(dot(normFill, lightDirFill), 0.0);
        vec3 diffuseFill = (fillLight.diffuse * (diffFill * textureColor2)) * blueTint;

        vec3 reflectDirFill = reflect(-lightDirFill, normFill);

        float specFill = pow(max(dot(-FragPos, reflectDirFill), 0.0), 16.0);
        vec3 specularFill = (fillLight.specular * (specFill * textureColor2))* blueTint;

        vec3 fillLightColor = ambientFill + diffuseFill + specularFill;
        
        // Mix the key light and fill light contributions
        vec3 finalColor = mix(keyLightColor, fillLightColor, blendFactor);

        FragColor = vec4(finalColor, 1.0);
    }

)";

// Functions
GLFWwindow* createWindow(int width, int height, const char* title)
{
    // Create a GLFW window
    GLFWwindow* window = glfwCreateWindow(width, height, "3D Scene by C. Mancini", nullptr, nullptr);

    if (window)
    {
        // Make the OpenGL context current
        glfwMakeContextCurrent(window);

        // Initialize GLEW
        if (glewInit() != GLEW_OK)

        // Error handling
        {
            std::cerr << "Failed to initialize GLEW" << std::endl;
            glfwDestroyWindow(window);
            window = nullptr;
        }
    }
    return window;
}

GLuint compileShader(GLenum type, const GLchar* source)
{
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    checkShaderCompilation(shader);
    return shader;
}

bool isOpenGLError()
{
    bool foundError = false;
    int glError = glGetError();

    // Error handling
    while (glError != GL_NO_ERROR) {
        cout << "glError: " << glError << std::endl;
        foundError = true;
        glError = glGetError();
    }

    return foundError;
}

void initGLFW()
{
    // Initialize GLFW
    if (!glfwInit())

    // Error handling
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        exit(-1);
    }

    // Configure GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
}

void initApp(GLFWwindow*& window, GLuint& shaderProgram, Camera& camera, MouseControl& mouseControl)
{
    // Initialize GLFW
    initGLFW();

    // Create a GLFW window
    window = createWindow(800, 600, "3D Scene by C. Mancini");

    // Error handling
    if (!window)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        exit(-1);
    }

    // Check for OpenGL errors specifically after window creation
    if (isOpenGLError()) {
        std::cerr << "OpenGL error occurred after window creation" << std::endl;
        exit(-1);
    }

    createShaderProgram(shaderProgram);

    // Set callacks for mouse movements
    glfwSetCursorPosCallback(window, mouseCallback);
    glfwSetScrollCallback(window, MouseControl::scrollCallback);

    // Create an instance of AppContext and set as user pointer
    static AppContext appContext = { &camera, &mouseControl };
    glfwSetWindowUserPointer(window, &appContext);

    // Disable cursor capturing
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
}

void checkLinking(GLuint program) {

    GLint success;
    GLchar infoLog[512];

    glGetProgramiv(program, GL_LINK_STATUS, &success);

    // Error handling
    if (!success) {
        glGetProgramInfoLog(program, 512, NULL, infoLog);
        std::cerr << "Program Linking Failed\n" << infoLog << std::endl;
    }
}

void createShaderProgram(GLuint& shaderProgram)
{
    GLuint vertexShader = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    GLuint fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    checkLinking(shaderProgram);

    // Delete the shader objects
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
}

void checkShaderCompilation(GLuint shader) {

    GLint success;
    GLchar infoLog[512];

    glGetShaderiv(shader, GL_LINK_STATUS, &success);

    // Error handling
    if (!success) {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cerr << "Shader Compilation Failed\n" << infoLog << std::endl;
    }
}

void setLightProperties(const GLuint shaderProgram, const Light& light, const std::string& name) {
    glUniform3fv(glGetUniformLocation(shaderProgram, (name + ".position").c_str()),  1, glm::value_ptr(light.position));
    glUniform3fv(glGetUniformLocation(shaderProgram, (name + ".direction").c_str()), 1, glm::value_ptr(light.direction));
    glUniform3fv(glGetUniformLocation(shaderProgram, (name + ".ambient").c_str()),   1, glm::value_ptr(light.ambient * light.intensity));
    glUniform3fv(glGetUniformLocation(shaderProgram, (name + ".diffuse").c_str()),   1, glm::value_ptr(light.diffuse * light.intensity));
    glUniform3fv(glGetUniformLocation(shaderProgram, (name + ".specular").c_str()),  1, glm::value_ptr(light.specular * light.intensity));
}

void createCylinder(std::vector<Vertex>& cylinderVertices, std::vector<unsigned int>& cylinderIndices,
    float radius, float height, int numSlices) {

    // Generate cylinder vertices for coffee mug
    for (int i = 0; i <= numSlices; ++i) {
        float angle = 2.0f * 3.142 * i / numSlices;
        float x = radius * cos(angle);
        float z = radius * sin(angle);
        float u = (float)i / numSlices; // Texture coordinate

        glm::vec3 sideNormal = glm::normalize(glm::vec3(x, 0.0f, z)); // Normal for the side

        // Bottom circle vertex
        cylinderVertices.emplace_back(glm::vec3(x, 0.0f, z), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(u, 0.0f)); // Normal pointing down (negative Y)

        // Top circle vertex
        cylinderVertices.emplace_back(glm::vec3(x, height, z), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(u, 1.0f)); // Normal pointing up (positive Y)
    }

    // Generate cylinder indices for sides of coffee mug
    for (int i = 0; i < numSlices; ++i) {
        cylinderIndices.push_back(2 * i);
        cylinderIndices.push_back(2 * i + 1);
        cylinderIndices.push_back(2 * (i + 1));

        cylinderIndices.push_back(2 * (i + 1));
        cylinderIndices.push_back(2 * i + 1);
        cylinderIndices.push_back(2 * (i + 1) + 1);
    }
}

void createHalfTorus(std::vector<Vertex>& torusVertices, std::vector<unsigned int>& torusIndices,
    float outerRadius, float innerRadius, int numSlices, int numStacks, const glm::vec3& color) {

    // Generate half torus vertices for coffee mug handle
    for (int stack = 0; stack <= numStacks; ++stack) {
        for (int slice = 0; slice <= numSlices; ++slice) {
            float stackAngle = 3.142 * stack / numStacks;
            float sliceAngle = 2.0f * 3.142 * slice / numSlices;
            float u = (float)slice / numSlices; // Texture coordinate U
            float v = (float)stack / numStacks; // Texture coordinate V

            float x = cos(stackAngle) * (outerRadius + innerRadius * cos(sliceAngle));
            float y = sin(stackAngle) * (outerRadius + innerRadius * cos(sliceAngle));
            float z = innerRadius * sin(sliceAngle);

            torusVertices.emplace_back(glm::vec3(x, y, z), color, glm::vec2(u, v));
        }
    }

    // Generate half torus indices for coffee mug handle
    for (int stack = 0; stack < numStacks; ++stack) {
        for (int slice = 0; slice < numSlices; ++slice) {
            int first = (stack * (numSlices + 1)) + slice;
            int second = first + numSlices + 1;

            torusIndices.push_back(first);
            torusIndices.push_back(second);
            torusIndices.push_back(first + 1);

            torusIndices.push_back(second);
            torusIndices.push_back(second + 1);
            torusIndices.push_back(first + 1);
        }
    }
}

void createTaperedCylinder(std::vector<Vertex>& cylinderVertices, std::vector<unsigned int>& cylinderIndices,
    float bottomRadius, float topRadius, float height, int numSlices) {

    // Generate vertices for the tapered cylinder (Dunkin cup)
    for (int i = 0; i <= numSlices; ++i) {
        float angle = 2.0f * 3.142 * i / numSlices;
        float xBottom = bottomRadius * cos(angle);
        float zBottom = bottomRadius * sin(angle);
        float xTop = topRadius * cos(angle);
        float zTop = topRadius * sin(angle);
        float u = (float)i / numSlices; // Texture coordinate

        glm::vec3 normal = glm::normalize(glm::vec3(xTop - xBottom, height, zTop - zBottom)); // Calculate normal

        // Bottom circle vertex
        cylinderVertices.emplace_back(glm::vec3(xBottom, 0.0f, zBottom), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(u, 0.0f)); // Normal pointing down (negative Y)

        // Top circle vertex
        cylinderVertices.emplace_back(glm::vec3(xTop, height, zTop), normal, glm::vec2(u, 1.0f)); // Normal for the side
    }

    // Generate indices for the sides of the tapered cylinder
    for (int i = 0; i < numSlices; ++i) {
        cylinderIndices.push_back(2 * i);
        cylinderIndices.push_back(2 * i + 1);
        cylinderIndices.push_back(2 * (i + 1));

        cylinderIndices.push_back(2 * (i + 1));
        cylinderIndices.push_back(2 * i + 1);
        cylinderIndices.push_back(2 * (i + 1) + 1);
    }
}

void createPencil(std::vector<Vertex>& pencilVertices, std::vector<unsigned int>& pencilIndices) {

    // Pencil dimensions
    float pencilLength = 9.0f;
    float pencilRadius = 0.15f;
    int numSlices = 32;

    // Clear existing data
    pencilVertices.clear();
    pencilIndices.clear();

    // Generate cylinder vertices for the pencil
    for (int i = 0; i <= numSlices; ++i) {
        float angle = 2.0f * 3.142f * i / numSlices;
        float x = pencilRadius * cos(angle);
        float z = pencilRadius * sin(angle);
        float u = (float)i / numSlices; // Texture coordinate

        glm::vec3 sideNormal = glm::normalize(glm::vec3(x, 0.0f, z)); // Normal for the side

        // Bottom circle vertex
        pencilVertices.emplace_back(glm::vec3(x, 0.0f, z), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(u, 0.0f));

        // Top circle vertex
        pencilVertices.emplace_back(glm::vec3(x, pencilLength, z), sideNormal, glm::vec2(u, 1.0f));
    }

    // Generate cylinder indices for the pencil
    for (int i = 0; i < numSlices; ++i) {
        pencilIndices.push_back(2 * i);
        pencilIndices.push_back(2 * i + 1);
        pencilIndices.push_back(2 * (i + 1));

        pencilIndices.push_back(2 * (i + 1));
        pencilIndices.push_back(2 * i + 1);
        pencilIndices.push_back(2 * (i + 1) + 1);
    }
}

void createRuler(std::vector<Vertex>& rulerVertices, std::vector<unsigned int>& rulerIndices) {
    // Ruler dimensions
    float length = 12.0f;        // 12 inches length
    float width = 1.0f;          // 1 inch width
    float thickness = 0.1f;      // 0.1 inches thickness

    // Half dimensions for center-based vertex positioning for ruler
    float halfLength = length / 2.0f;
    float halfWidth = width / 2.0f;
    float halfThickness = thickness / 2.0f;

    // Clear existing data
    rulerVertices.clear();
    rulerIndices.clear();

    // Ruler vertex data      
    rulerVertices = {
        // Front face
        Vertex(glm::vec3(-halfLength, -halfWidth, halfThickness), glm::vec3(0.0f, 0.0f, 1.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(halfLength, -halfWidth, halfThickness), glm::vec3(0.0f, 0.0f, 1.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(halfLength,  halfWidth, halfThickness), glm::vec3(0.0f, 0.0f, 1.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(-halfLength,  halfWidth, halfThickness), glm::vec3(0.0f, 0.0f, 1.0f), glm::vec2(0.0f, 1.0f)),

        // Back face
        Vertex(glm::vec3(-halfLength, -halfWidth, -halfThickness), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(halfLength, -halfWidth, -halfThickness), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(halfLength,  halfWidth, -halfThickness), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec2(0.0f, 1.0f)),
        Vertex(glm::vec3(-halfLength,  halfWidth, -halfThickness), glm::vec3(0.0f, 0.0f, -1.0f), glm::vec2(1.0f, 1.0f)),

        // Left face
        Vertex(glm::vec3(-halfLength, -halfWidth, -halfThickness), glm::vec3(-1.0f, 0.0f, 0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-halfLength,  halfWidth, -halfThickness), glm::vec3(-1.0f, 0.0f, 0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(-halfLength,  halfWidth,  halfThickness), glm::vec3(-1.0f, 0.0f, 0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(-halfLength, -halfWidth,  halfThickness), glm::vec3(-1.0f, 0.0f, 0.0f), glm::vec2(0.0f, 1.0f)),

        // Right face
        Vertex(glm::vec3(halfLength, -halfWidth, -halfThickness), glm::vec3(1.0f, 0.0f, 0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(halfLength,  halfWidth, -halfThickness), glm::vec3(1.0f, 0.0f, 0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(halfLength,  halfWidth,  halfThickness), glm::vec3(1.0f, 0.0f, 0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(halfLength, -halfWidth,  halfThickness), glm::vec3(1.0f, 0.0f, 0.0f), glm::vec2(0.0f, 1.0f)),

        // Top face
        Vertex(glm::vec3(-halfLength, halfWidth, -halfThickness), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-halfLength, halfWidth,  halfThickness), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(halfLength, halfWidth,  halfThickness), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(halfLength, halfWidth, -halfThickness), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 1.0f)),

        // Bottom face
        Vertex(glm::vec3(-halfLength, -halfWidth, -halfThickness), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-halfLength, -halfWidth,  halfThickness), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(halfLength, -halfWidth,  halfThickness), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(halfLength, -halfWidth, -halfThickness), glm::vec3(0.0f, -1.0f, 0.0f), glm::vec2(0.0f, 1.0f))
    };


    // Ruler index data
    rulerIndices = {
        // Front face
        0, 1, 2, 2, 3, 0,

        // Back face
        4, 5, 6, 6, 7, 4,

        // Left face
        8, 9, 10, 10, 11, 8,

        // Right face
        12, 13, 14, 14, 15, 12,

        // Top face
        16, 17, 18, 18, 19, 16,

        // Bottom face
        20, 21, 22, 22, 23, 20
    };


};

void applyProjectionAndMatrix(GLuint shaderProgram, const glm::mat4& modelMatrix, const glm::mat4& viewMatrix, bool isPerspectiveView)
{
    // Pass transformation matrices to the shader
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
    GLint projectionLoc = glGetUniformLocation(shaderProgram, "projection");

    // Set uniforms for model and view
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMatrix));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));

    // Set the perspective or orthographic projection matrix based on isPerspectiveView
    float aspectRatio = 800.0f / 600.0f;
    glm::mat4 projection;

    if (isPerspectiveView) {
        projection = glm::perspective(glm::radians(55.0f), aspectRatio, 0.1f, 100.0f);
    }
    else {
        projection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.1f, 100.0f);
    }

    glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
}

void renderShape(const GLMesh& mesh) {

    // Bind VAO and draw the mesh

    mesh.bindVAO();
    glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(mesh.getIndicesCount()), GL_UNSIGNED_INT, 0);

    // Unbind the VAO
    glBindVertexArray(0);

}

void renderScene(GLFWwindow* window, GLMesh& mesh, GLuint& shaderProgram, Camera& camera, bool isPerspectiveView, Texture& texture1, Texture& texture2, float blendFactor, TransformData& transformData)
{
    // Enable depth testing
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glDepthMask(GL_TRUE);

    // Key Light instantiation and initialization
    Light keyLight;
    keyLight.position  = glm::vec3(0.0f, 2.0f, 10.0f);
    keyLight.direction = glm::vec3(0.0f, 1.0f, 0.0f);
    keyLight.ambient   = glm::vec3(0.3f, 0.3f, 0.3f);
    keyLight.diffuse   = glm::vec3(0.9f, 0.5f, 0.9f);
    keyLight.specular  = glm::vec3(2.0f, 2.0f, 1.0f);
    keyLight.intensity = 1.0f; // 100%    
    
    // Fill Light instantiation and initialization
    Light fillLight;
    fillLight.position  = glm::vec3(1.0f, 6.0f, 5.0f); 
    fillLight.direction = glm::vec3(0.0f, -1.0f, 0.0f);
    fillLight.ambient   = glm::vec3(0.3f, 0.3f, 0.3f);
    fillLight.diffuse   = glm::vec3(0.6f, 0.6f, 0.6f);
    fillLight.specular  = glm::vec3(0.7f, 0.7f, 0.7f);
    fillLight.intensity = 1.0f; // 100%

    // Attach shader
    glUseProgram(shaderProgram);
    setLightProperties(shaderProgram, keyLight, "keyLight");
    setLightProperties(shaderProgram, fillLight, "fillLight");    

    // Bind texture   
    texture1.bind(GL_TEXTURE0);
    texture2.bind(GL_TEXTURE1);

    // Set uniforms
    glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);
    glUniform1i(glGetUniformLocation(shaderProgram, "texture2"), 1);
    glUniform1f(glGetUniformLocation(shaderProgram, "blendFactor"), blendFactor);

    // Apply matrices
    glm::mat4 modelMatrix = transformData.toMatrix();

    glm::mat4 viewMatrix = camera.GetViewMatrix();

    applyProjectionAndMatrix(shaderProgram, modelMatrix, viewMatrix, isPerspectiveView);

    // Draw specific object
    renderShape(mesh);
}

void mouseCallback(GLFWwindow* window, double xpos, double ypos) {

    // Use pointers struct
    AppContext* appContext = static_cast<AppContext*>(glfwGetWindowUserPointer(window));

    if (appContext && appContext->camera && appContext->mouseControl) {
        appContext->mouseControl->processMouseMovement(window, *appContext->camera, 0.0f);
    }
}

void processInput(GLFWwindow* window, Camera& camera, float deltaTime, bool& isPerspectiveView)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {            // escape key to exit
        glfwSetWindowShouldClose(window, true);
    }

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {                 // W key to move cam forward

        camera.ProcessKeyboard(FORWARD, deltaTime);
    }

    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
        camera.ProcessKeyboard(BACKWARD, deltaTime);                    // S key to move cam backward
    }

    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
        camera.ProcessKeyboard(LEFT, deltaTime);                        // A key to move cam left
    }

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
        camera.ProcessKeyboard(RIGHT, deltaTime);                       // D key to move cam right
    }

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
        camera.ProcessKeyboard(UP, deltaTime);                          // Q key to move cam up
    }

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
        camera.ProcessKeyboard(DOWN, deltaTime);                        // E key to move cam down
    }

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)                   // P key toggles 3D-to-Orthographic view
        isPerspectiveView = !isPerspectiveView;
}

void adjustCameraSpeed(Camera& camera, float offset) {

    float newSpeed = camera.MovementSpeed + offset * 0.1f;
    
    // Set speed limits
    newSpeed = std::max(0.1f, std::min(newSpeed, 10.0f));

    camera.MovementSpeed = newSpeed;
}



// MAIN Function

int main()
{
    GLFWwindow* window;
    GLuint shaderProgram;
    MouseControl mouseControl;

    float LastFrame = 0.0f;
    static bool isPerspectiveView = true;

    // camera instance & initialization
    Camera camera(glm::vec3(3.0f, 4.0f, 9.0f)); 

    // Plane vertices/indices data
    std::vector<Vertex> planeVertices = {

        Vertex(glm::vec3(-12.0f, -15.0f, -10.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-12.0f, -10.0f, -10.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(12.0f, -10.0f, -10.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(12.0f, -15.0f, -10.0f), glm::vec3(0.0f, 1.0f, 0.0f), glm::vec2(0.0f, 1.0f)),
    };
    std::vector<unsigned int> planeIndices = {

        0, 1, 2, 0, 2, 3,
    };

    // Parameters for cylinder for coffee mug (body)
    float cylinderRadius = 1.0f;
    float cylinderHeight = 2.0f;
    int cylinderSlices = 32;
    glm::vec3 cylinderColor = glm::vec3(0.0f, 0.0f, 3.0f); // blue

    // data structure to hold cylinder vertex & index calculations
    std::vector<Vertex> cylinderVertices;
    std::vector<unsigned int> cylinderIndices;

    // Parameters for half torus for coffee mug handle
    float torusOuterRadius = 1.05f;
    float torusInnerRadius = 0.3f;
    int torusSlices = 32;
    int torusStacks = 16;
    glm::vec3 torusColor = glm::vec3(1.0f, 0.5f, 0.2f);  // orange

    // data structure to hold cup handle vertex & index calculations
    std::vector<Vertex> torusVertices;
    std::vector<unsigned int> torusIndices;

    // Parameters for tapered cylinder for Dunkin cup
    float dunkinCupBottomRadius = 1.25f; 
    float dunkinCupTopRadius = 2.0f;   
    float dunkinCupHeight = 6.0f;
    int dunkinCupSlices = 16;
    glm::vec3 dunkinCupColor = glm::vec3(1.0f, 1.0f, 1.0f); // white

    // data structure to hold Dunkin vertex/index calculations
    std::vector<Vertex> dunkinVertices;
    std::vector<unsigned int> dunkinIndices;

    // Vertex/Indices data for a perfect cube 
    std::vector<Vertex> cubeVertices = {

        // Front face (z = 0.5f)
        Vertex(glm::vec3(-0.5f, -0.5f,  0.5f),  glm::vec3(0.0f,  0.0f,  1.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(0.5f, -0.5f,  0.5f),  glm::vec3(0.0f,  0.0f,  1.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(0.5f,  0.5f,  0.5f),  glm::vec3(0.0f,  0.0f,  1.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(-0.5f,  0.5f,  0.5f),  glm::vec3(0.0f,  0.0f,  1.0f), glm::vec2(0.0f, 1.0f)),     

        // Back face (z = -0.5f)
        Vertex(glm::vec3(-0.5f, -0.5f, -0.5f),  glm::vec3(0.0f,  0.0f, -1.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(0.5f, -0.5f, -0.5f),  glm::vec3(0.0f,  0.0f, -1.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(0.5f,  0.5f, -0.5f),  glm::vec3(0.0f,  0.0f, -1.0f), glm::vec2(0.0f, 1.0f)),
        Vertex(glm::vec3(-0.5f,  0.5f, -0.5f),  glm::vec3(0.0f,  0.0f, -1.0f), glm::vec2(1.0f, 1.0f)),

        // Left face (x = -0.5f)
        Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 1.0f)),

        // Right face (x = 0.5f)
        Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec3(1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec3(1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec3(1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 1.0f)),
        Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec3(1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 1.0f)),

        // Top face (y = 0.5f)
        Vertex(glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec3(0.0f,  1.0f,  0.0f), glm::vec2(0.0f, 1.0f)),
        Vertex(glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec3(0.0f,  1.0f,  0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(0.5f,  0.5f,  0.5f), glm::vec3(0.0f,  1.0f,  0.0f), glm::vec2(1.0f, 0.0f)),
        Vertex(glm::vec3(0.5f,  0.5f, -0.5f), glm::vec3(0.0f,  1.0f,  0.0f), glm::vec2(1.0f, 1.0f)),

        // Bottom face (y = -0.5f)
        Vertex(glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec3(0.0f, -1.0f,  0.0f), glm::vec2(0.0f, 0.0f)),
        Vertex(glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec3(0.0f, -1.0f,  0.0f), glm::vec2(0.0f, 1.0f)),
        Vertex(glm::vec3(0.5f, -0.5f,  0.5f), glm::vec3(0.0f, -1.0f,  0.0f), glm::vec2(1.0f, 1.0f)),
        Vertex(glm::vec3(0.5f, -0.5f, -0.5f), glm::vec3(0.0f, -1.0f,  0.0f), glm::vec2(1.0f, 0.0f)),
    };
    std::vector<unsigned int> cubeIndices = {
        // Front face
        0, 1, 2, 2, 3, 0,

        // Back face
        4, 5, 6, 6, 7, 4,

        // Left face
        8, 9, 10, 10, 11, 8,

        // Right face
        12, 13, 14, 14, 15, 12,

        // Top face
        16, 17, 18, 18, 19, 16,

        // Bottom face
        20, 21, 22, 22, 23, 20
    };
    
    // data structures for the ruler vertex & index data
    std::vector<Vertex> rulerVertices;
    std::vector<unsigned int> rulerIndices;

    // data structures for the pencil vertex & index data
    std::vector<Vertex> pencilVertices;
    std::vector<unsigned int> pencilIndices;
   
    try {

        // Initialize application
        initApp(window, shaderProgram, camera, mouseControl);

        // Load images   
        Texture texture1("..\\..\\..\\..\\darkWood.PNG");      
        Texture texture2("..\\..\\..\\..\\brightBlue.PNG");      
        Texture texture3("..\\..\\..\\..\\gold.PNG");
        Texture texture4("..\\..\\..\\..\\wallpaper.jpg");  // brick
        Texture texture5("..\\..\\..\\..\\Dunkin2.png");
        Texture texture6("..\\..\\..\\..\\screenShot2.PNG");
        Texture texture7("..\\..\\..\\..\\grey stand.PNG");
        Texture texture8("..\\..\\..\\..\\orangeSlice.PNG");
        Texture texture9("..\\..\\..\\..\\pencil.PNG");
        Texture texture10("..\\..\\..\\..\\CeramicPlainWhite001_COL_1K.jpg");

        // Set blendFactor for advanced texturing technique
        float blendFactor = 0.5f;

        // Create & Transform Desktop
        GLMesh planeMesh(planeVertices, planeIndices);
        TransformData planeTransformed = TransformData(glm::vec3(2.0f, -3.0f, 8.50f), glm::vec3(120.0f, -180.0f, 0.0f), glm::vec3(1.75f));

        // Create & Transform Coffee Mug- Body only
        createCylinder(cylinderVertices, cylinderIndices, cylinderRadius, cylinderHeight, cylinderSlices);
        GLMesh cylinderMesh(cylinderVertices, cylinderIndices);
        TransformData cylinderTransformed = TransformData(glm::vec3(11.0f, -3.70f, -10.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.5f));

        // Create & Transform Coffee Mug- Handle only
        createHalfTorus(torusVertices, torusIndices, torusOuterRadius, torusInnerRadius, torusSlices, torusStacks, torusColor);
        GLMesh halfTorusMesh(torusVertices, torusIndices);      
        TransformData halfTorusTransformed = TransformData(glm::vec3(9.50f, -1.9f, -10.0f), glm::vec3(0.0f, 0.0f, 90.0f), glm::vec3(0.90f));

        // Create & Transform Dunkin Cup
        createTaperedCylinder(dunkinVertices, dunkinIndices, dunkinCupBottomRadius, dunkinCupTopRadius, dunkinCupHeight, dunkinCupSlices);
        GLMesh dunkinMesh(dunkinVertices, dunkinIndices);
        TransformData dunkinTransformed = TransformData(glm::vec3(-4.5f, -3.70f, -9.0f), glm::vec3(0.0f, 110.0f, 0.0f), glm::vec3(.60f, .82f, .72f));

        // Create & Transform Computer Monitor
        GLMesh cubeMesh(cubeVertices, cubeIndices);
        TransformData cubeTransformed = TransformData(glm::vec3(2.0f, 4.0f, -15.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(20.0f, 12.0f, 0.5f));

        // Create & Transform Computer Monitor Stand - Support Column
        GLMesh supportMesh(cylinderVertices, cylinderIndices);
        TransformData supportTransformed = TransformData(glm::vec3(2.0f, -3.75f, -15.50f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(1.0f, 1.0f, 0.5f));    

        // Create & Transform Computer Monitor Stand - Base Platform
        GLMesh baseMesh(cubeVertices, cubeIndices);
        TransformData baseTransformed = TransformData(glm::vec3(2.0f, -4.0f, -15.5f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(7.0f, 0.70f, 1.0f));

        // Create & Transform Ruler
        createRuler(rulerVertices, rulerIndices);
        GLMesh rulerMesh(rulerVertices, rulerIndices);
        TransformData rulerTransformed = TransformData(glm::vec3(10.7f, 1.0f, -10.0f), glm::vec3(0.0f, 0.0f, 90.0f), glm::vec3(0.8f, 0.95f, 0.25f));

        // Create & Transform Pencil
        createPencil(pencilVertices, pencilIndices);
        GLMesh pencilMesh(pencilVertices, pencilIndices);
        TransformData pencilTransformed = TransformData(glm::vec3(11.70f, -3.5f, -10.0f), glm::vec3(0.0f, 0.0f, 24.0f), glm::vec3(0.65f));
     
        // Render loop
        while (!glfwWindowShouldClose(window))
        {   
            // Get the current time
            double currentFrameTime = glfwGetTime();

            // Calculate deltaTime
            float deltaTime = static_cast<float>(currentFrameTime - LastFrame);

            // Update the previous frame's time
            LastFrame = currentFrameTime;

            // Process direct user input from keyboard
            processInput(window, camera, deltaTime, isPerspectiveView);

            // Clear the screen
            glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            // Render desktop
            renderScene(window, planeMesh, shaderProgram, camera, isPerspectiveView, texture1, texture1, blendFactor, planeTransformed);

            // Render coffee mug with handle 
            renderScene(window, cylinderMesh, shaderProgram, camera, isPerspectiveView, texture2, texture10, 0.75f, cylinderTransformed);
            renderScene(window, halfTorusMesh, shaderProgram, camera, isPerspectiveView, texture2, texture10, 0.75f, halfTorusTransformed);            

            // Render Dunkin cup
            renderScene(window, dunkinMesh, shaderProgram, camera, isPerspectiveView, texture5, texture5, 0.6f, dunkinTransformed);

            // Render computer monitor, support & base
            renderScene(window, cubeMesh, shaderProgram, camera, isPerspectiveView, texture6, texture6, 0.60f, cubeTransformed);
            renderScene(window, supportMesh, shaderProgram, camera, isPerspectiveView, texture7, texture7, 0.60f, supportTransformed);
            renderScene(window, baseMesh, shaderProgram, camera, isPerspectiveView, texture7, texture7, 0.60f, baseTransformed); 
          
            // Render ruler
            renderScene(window, rulerMesh, shaderProgram, camera, isPerspectiveView, texture8, texture8, blendFactor, rulerTransformed);

            // Render pencil
            renderScene(window, pencilMesh, shaderProgram, camera, isPerspectiveView, texture9, texture9, blendFactor, pencilTransformed);
         
            // Swap buffers and poll events
            glfwSwapBuffers(window);
            glfwPollEvents();
        }
    }

    // Error and exception handling
    catch (const std::exception& e) {

        std::cerr << "Exception caught: " << e.what() << std::endl;

        glDeleteProgram(shaderProgram);

        return -1;
    }

    // cleanup
    glDeleteProgram(shaderProgram);
    glfwTerminate();

    return 0;
}





